<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Services\OracleConnectionService;
use App\Services\AccessProvisioningService;
use App\Services\OracleDiscoveryService;

/**
 * Contrôleur de Gestion des Rôles Fonctionnels Oracle (Section 13)
 */
class RoleController extends Controller
{
    private OracleConnectionService $connectionService;

    public function __construct()
    {
        parent::__construct();
        $this->connectionService = new OracleConnectionService();
    }

    public function index(Request $request): Response
    {
        $db = $this->connectionService->getActiveConnection();
        if (!$db) return $this->redirect('/servers');

        $paramPdb = trim((string)$request->query('pdb', ''));
        if (!empty($paramPdb) && zirioam_is_valid_oracle_identifier($paramPdb)) {
            $activePdb = strtoupper($paramPdb);
            $this->session->set('current_pdb', $activePdb);
        } else {
            $activePdb = $this->session->get('current_pdb');
        }

        $discovery = new OracleDiscoveryService($db);
        $pdbs = $discovery->discoverPdbs();

        // Si aucune PDB active, prendre la première ouverte
        if (empty($activePdb) && !empty($pdbs)) {
            foreach ($pdbs as $p) {
                if ($p['OPEN_MODE'] === 'READ WRITE') {
                    $activePdb = $p['NAME'];
                    $this->session->set('current_pdb', $activePdb);
                    break;
                }
            }
        }

        $roles = [];
        $schemas = [];
        if (!empty($activePdb)) {
            $accessService = new AccessProvisioningService($db);
            $roles = $accessService->getRoles($activePdb);
            $schemas = $discovery->discoverApplicationSchemas();
        }

        return $this->render('roles.index', [
            'roles' => $roles,
            'schemas' => $schemas,
            'activePdb' => $activePdb,
            'pdbs' => $pdbs,
        ]);
    }

    public function store(Request $request): Response
    {
        $db = $this->connectionService->getActiveConnection();
        if (!$db) return $this->redirect('/servers');

        $postPdb = trim((string)$request->post('pdb', ''));
        $activePdb = (!empty($postPdb) && zirioam_is_valid_oracle_identifier($postPdb)) ? strtoupper($postPdb) : $this->session->get('current_pdb');
        if (!empty($activePdb)) {
            $this->session->set('current_pdb', $activePdb);
        }
        if (empty($activePdb)) {
            $this->flash('danger', "Veuillez d'abord sélectionner une PDB active.");
            return $this->redirect('/databases');
        }

        $schema = (string)$request->post('target_schema');
        $profileType = (string)$request->post('profile_type');
        $description = (string)$request->post('description');
        $customRoleName = trim((string)$request->post('custom_role_name', ''));
        $dbaUser = $this->session->get('current_user', 'DBA');

        $accessService = new AccessProvisioningService($db);

        try {
            $accessService->createRole($activePdb, $schema, $profileType, $description, $dbaUser, $customRoleName ?: null);
            $this->flash('success', "Le rôle fonctionnel a été créé et les privilèges d'objets ont été synchronisés avec succès dans la PDB {$activePdb}.");
        } catch (\Throwable $e) {
            $this->flash('danger', "Erreur lors de la création du rôle : " . $e->getMessage());
        }

        return $this->redirect('/roles');
    }

    /**
     * Synchronise les privilèges sur toutes les tables et vues du schéma vers le rôle
     */
    public function sync(Request $request, array $params): Response
    {
        $db = $this->connectionService->getActiveConnection();
        if (!$db) return $this->redirect('/servers');

        $postPdb = trim((string)$request->post('pdb', ''));
        $activePdb = (!empty($postPdb) && zirioam_is_valid_oracle_identifier($postPdb)) ? strtoupper($postPdb) : $this->session->get('current_pdb');
        if (!empty($activePdb)) {
            $this->session->set('current_pdb', $activePdb);
        }
        if (empty($activePdb)) {
            $this->flash('danger', "Veuillez d'abord sélectionner une PDB active.");
            return $this->redirect('/roles');
        }

        $id = (int)($params['id'] ?? 0);
        $accessService = new AccessProvisioningService($db);
        $db->switchContainer($activePdb);

        $roleRow = $db->queryOne(
            "SELECT ROLE_ID, ROLE_NAME, TARGET_SCHEMA, PROFILE_TYPE FROM ZIRIOAM_OWNER.ZIRIOAM_ACCESS_ROLES WHERE ROLE_ID = :rid",
            ['rid' => $id]
        );

        if (!$roleRow) {
            $this->flash('danger', "Rôle introuvable.");
            return $this->redirect('/roles');
        }

        try {
            $res = $accessService->syncSchemaPrivilegesToRole(
                $roleRow['TARGET_SCHEMA'],
                $roleRow['ROLE_NAME'],
                $roleRow['PROFILE_TYPE'] ?? 'APP_READ_WRITE'
            );

            // Résolution ORA-01950 : Accorder automatiquement les quotas tablespace aux développeurs associés
            // Et si rôle APP_ALL, appliquer GRANT ALL ON obj TO user sur tous les objets du schéma cible
            $isAllProfile = in_array(strtoupper(trim((string)($roleRow['PROFILE_TYPE'] ?? ''))), ['APP_ALL', 'ALL'], true);
            $userGrantsCount = 0;
            try {
                $devs = $db->query(
                    "SELECT USERNAME FROM ZIRIOAM_OWNER.ZIRIOAM_DEVELOPER_ACCESS WHERE ROLE_ID = :rid AND STATUS = 'ACTIVE'",
                    ['rid' => $id]
                );
                foreach ($devs as $d) {
                    $u = $d['USERNAME'] ?? '';
                    if (!empty($u)) {
                        $normUser = strtoupper(trim($u));
                        $baseUser = str_starts_with($normUser, 'C##') ? substr($normUser, 3) : $normUser;
                        $localRole = 'RL_' . $baseUser;
                        $accessService->grantTablespaceQuotaForSchema($u, $roleRow['TARGET_SCHEMA'], $localRole);
                        if ($isAllProfile) {
                            $uRes = $accessService->grantAllSchemaObjectsToUser($roleRow['TARGET_SCHEMA'], $normUser);
                            $userGrantsCount += count($uRes['granted'] ?? []);
                        }
                    }
                }
            } catch (\Throwable $qe) {}

            $count = count($res['granted'] ?? []);
            $errCount = count($res['errors'] ?? []);
            if ($errCount > 0) {
                $errDetails = implode(', ', array_slice($res['errors'], 0, 3));
                $this->flash('warning', "{$count} objet(s) accordé(s), {$errCount} erreur(s) pour {$roleRow['ROLE_NAME']} : {$errDetails}");
            } elseif ($count === 0 && $userGrantsCount === 0) {
                $this->flash('info', "Aucun objet éligible trouvé pour le schéma {$roleRow['TARGET_SCHEMA']} dans la PDB {$activePdb}.");
            } else {
                $extraMsg = $userGrantsCount > 0 ? " (+ {$userGrantsCount} GRANT ALL direct(s) aux développeurs attribués)" : "";
                $this->flash('success', "{$count} objet(s) du schéma {$roleRow['TARGET_SCHEMA']} synchronisé(s) avec succès sur le rôle {$roleRow['ROLE_NAME']}{$extraMsg}.");
            }
        } catch (\Throwable $e) {
            $this->flash('danger', "Erreur lors de la synchronisation : " . $e->getMessage());
        }

        return $this->redirect('/roles');
    }

    /**
     * Supprime un rôle applicatif de la PDB et du catalogue
     */
    public function destroy(Request $request, array $params): Response
    {
        $db = $this->connectionService->getActiveConnection();
        if (!$db) return $this->redirect('/servers');

        $postPdb = trim((string)$request->post('pdb', ''));
        $activePdb = (!empty($postPdb) && zirioam_is_valid_oracle_identifier($postPdb)) ? strtoupper($postPdb) : $this->session->get('current_pdb');
        if (!empty($activePdb)) {
            $this->session->set('current_pdb', $activePdb);
        }
        if (empty($activePdb)) {
            $this->flash('danger', "Veuillez d'abord sélectionner une PDB active.");
            return $this->redirect('/roles');
        }

        $id = (int)($params['id'] ?? 0);
        $dbaUser = $this->session->get('current_user', 'DBA');
        $accessService = new AccessProvisioningService($db);

        try {
            $accessService->deleteRole($activePdb, $id, $dbaUser);
            $this->flash('success', "Le rôle applicatif a été supprimé avec succès de la PDB {$activePdb}.");
        } catch (\Throwable $e) {
            $this->flash('danger', "Erreur lors de la suppression du rôle : " . $e->getMessage());
        }

        return $this->redirect('/roles');
    }
}

